/******************************************************************************
 Copyright© HITwh HERO-Robomaster2020 Group

 Author: Wang Xiaoyan on 2019.9.20

 Detail:
 *****************************************************************************/

#ifndef pipei_WORKSPACE_H
#define pipei_WORKSPACE_H

#include <iostream>
#include <vector>
#include <thread>
#include <mutex>
#include <sstream>
#include <unistd.h>
#include <opencv2/opencv.hpp>

#include "targetsolver.h"
#ifdef RUNNING_TIME
#include "timer.h"
#endif

using namespace std;
using namespace cv;


typedef struct SendPack_t {
    double yaw;
    double pitch;
}SendPack;

typedef struct ReadPack_t {
    int enemy;  // 0-red, 1-blue
    int mode;
}ReadPack;

class Workspace {
private:
    enum Mode {
        ARMOR,
        RUNE
    };

    TargetSolver target_solver;

    RotatedRect lightbars_;
    Target target_;
public:
    Workspace();
    ~Workspace();
    void init(const FileStorage &file_storage);
    void run();


};


#endif  // HERORM2020_WORKSPACE_H

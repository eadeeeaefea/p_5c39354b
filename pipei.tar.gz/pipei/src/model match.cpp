#include <opencv2/opencv.hpp>
#include <math.h>
#include <iostream>
 
using namespace cv;
using namespace std;
 
#define SQDIFF 0
#define SADIFF 1
 
float templateMatch(const Mat & src, const Mat & temp, int & i_match, int & j_match, int Match_methold)
{
	int src_cols = src.cols;
	int src_rows = src.rows;
	int temp_cols = temp.cols;
	int temp_rows = temp.rows;
 
	int i_end = src_rows - temp.rows + 1;
	int j_end = src.cols - temp.cols + 1;
 
	float match_degree = FLT_MAX;
 
	for (int i = 0; i < i_end; i++)
	{
		for (int j = 0; j < j_end; j++)
		{
			float match_ij = 0.0;
 
			for (int m = 0; m < temp_rows; m++)
			{
				for (int n = 0; n < temp_cols; n++)
				{
					uchar val_s = src.at<uchar>(i + m, j + n);
					uchar val_t = temp.at<uchar>(m, n);
					if (Match_methold == SQDIFF)
					{
						match_ij += float((val_t - val_s) * (val_t - val_s));
					}
					else if (Match_methold == SADIFF)
					{
						match_ij += float(abs(val_t - val_s));
					}
				}
			}
			
			//cout << match_ij << endl;
			if (match_ij < match_degree)
			{
				match_degree = match_ij;
				i_match = i;
				j_match = j;
			}
		}
	}
	
 
	return match_degree;
 
}
  
int main()
{
        VideoCapture cap("../avi/blue_6m.avi");
    if (!cap.isOpened()) {
        cout << "Cannot open the video" << endl;
        return -1;
    }

    int image_count=0;
    while (true)
    {
        Mat imgOriginal;
        bool bSuccess = cap.read(imgOriginal);
        if (!bSuccess) {
            cout << "Cannot read a frame from video stream" << endl;
            break;
        }
        image_count=image_count+1;
        cout << "正在写第" << image_count << "帧" << endl;
        std::stringstream str;
        str <<"../dataset1/"<< image_count<< ".jpg";
        imwrite(str.str(),imgOriginal);
    }

 
	Mat src;
        Mat temp = imread("../muban1.jpg", CV_LOAD_IMAGE_GRAYSCALE);
        int count =0; 
        string img_name;
        while(count++<239){
        img_name = "../dataset/" + to_string(count) + ".jpg"; 
        src=imread(img_name, CV_LOAD_IMAGE_GRAYSCALE);
//imread("../dataset/3.jpg", CV_LOAD_IMAGE_GRAYSCALE);
	float match_degree = 0;
	int i_match = -1, j_match = -1;
	match_degree = templateMatch(src, temp, i_match, j_match, SADIFF);
	
	cout << i_match << "," << j_match << "," << match_degree << endl;
 
	Mat src_color;
	cvtColor(src, src_color, COLOR_GRAY2BGR);
        Mat element = getStructuringElement(MORPH_RECT, Size(3, 3));         
        erode(src_color, src_color, element);
        dilate(src_color, src_color, element);
	rectangle(src_color, Rect(j_match, i_match, temp.cols, temp.rows), Scalar(255, 0, 0));
        threshold(src_color, src_color, 30, 255, THRESH_BINARY);
	imshow("result", src_color);
        waitKey(27);
        }
	
 
	return 0;
}


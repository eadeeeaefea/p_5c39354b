#include <opencv2/opencv.hpp>
#include <iostream>

using namespace std;
using namespace cv;

int main()
{
    VideoCapture cap("../avi/8m_400_1.avi");
    if (!cap.isOpened()) {
        cout << "Cannot open the video" << endl;
        return -1;
    }


    Mat src, sample, dst, dst1;
    Mat lightbars_;
    Mat element = getStructuringElement(MORPH_RECT, Size(3, 3)); 
    while(1)
    {
        cap >> src;
       // src = imread("../dataset1/");
        vector<Mat> channels;
        cvtColor(src, sample, COLOR_BGR2GRAY);
        threshold(sample, sample, 20, 255, THRESH_BINARY);
        split(src, channels);
        subtract(channels[0], channels[2], dst);
        threshold(dst, dst, 20, 255, THRESH_BINARY);
        sample = dst & sample;

        cvtColor(src, dst1, COLOR_BGR2HSV);
        inRange(dst1, Scalar(50, 43, 46), Scalar(124, 255, 255), dst1);
        erode(dst1, dst1, element);
        dilate(dst1, dst1, element);
        
        sample = dst1 & sample;
        imshow("hsv", sample);
        waitKey(0);
        
        Mat kernel_ = getStructuringElement(MORPH_RECT, Size(3,3));
        morphologyEx(sample, sample, MORPH_OPEN, kernel_);

        vector<Vec4i> hierarchy;
        vector<vector<Point2i>> temp_contours;
        RotatedRect temp_rrect_;
        vector<RotatedRect> lightbars_;
        vector<vector<Point2i>> contours;
        //GaussianBlur(sample, sample, Size(5, 5), 3, 3);
        findContours(sample, temp_contours, hierarchy, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
       //cout << temp_contours.size() <<endl;

        
      Point2f lu, ld, ru, rd;
        for (int j = 0; j < temp_contours.size(); ++j){
             temp_rrect_ = minAreaRect(temp_contours[j]);  
         if ((temp_rrect_.size.width * temp_rrect_.size.height > 5) && ((-47 < temp_rrect_.angle < -25)||(-65 < temp_rrect_.angle < -50))) {
            lightbars_.push_back(temp_rrect_);
            contours.push_back(temp_contours[j]);
        }
          }
    cout << lightbars_.size() << endl;

       Point2f left_center_, right_center_;
       for(int j = 0; j < lightbars_.size()-1; ++j){
            left_center_ = lightbars_[j].center;
             for(int k = 0; k < lightbars_.size(); ++k){
                   right_center_ = lightbars_[k].center;
                   cout << lightbars_[k].angle << endl;
              }
                 
                    }

          if(lightbars_.size() == 2){
            for(int k = 1; k < contours[1].size(); k++){
              if(contours[1][k].y < contours[1][k-1].y){
                 lu.y = contours[1][k].y;
               }
              if(contours[1][k].x > contours[1][k-1].x){
                 lu.x = contours[1][k].x;
              } 
              if(contours[1][k].y > contours[1][k-1].y){
                 ld.y = contours[1][k].y;
               }
              if(contours[1][k].x < contours[1][k-1].x){
                 ld.x = contours[1][k].x;
              } 
          }
             for(int i = 1; i < contours[0].size(); i++){
              if(contours[0][i].y < contours[0][i-1].y){
                 ru.y = contours[0][i].y;
               }
              if(contours[0][i].x < temp_contours[0][i-1].x){
                 ru.x = contours[0][i].x;
              } 
              if(contours[0][i].y > contours[0][i-1].y){
                 rd.y = contours[0][i].y;
               }
              if(contours[0][i].x > contours[0][i-1].x){
                 rd.x = contours[0][i].x;
              } 
          }
         
          circle(src, Point(lu.x,lu.y), 1, Scalar(0,255,0),1,8);   
          circle(src, Point(ld.x,ld.y), 1, Scalar(0,255,0),1,8);  
          circle(src, Point(ru.x,ru.y), 1, Scalar(0,255,0),1,8);   
          circle(src, Point(rd.x,rd.y), 1, Scalar(0,255,0),1,8);  
          line(src, lu, ru, (0, 255, 255), 2);
          line(src, ru, rd, (0, 255, 255), 2);
          line(src, rd, ld, (0, 255, 255), 2);
          line(src, ld, lu, (0, 255, 255), 2);
    

         

          Point2f center;
          center.x = (left_center_.x + right_center_.x) *0.5;
         // center.y = ld.y - (ld.y - lu.y)*(2 * (ru.x - lu.x) + (rd.x - ld.x))/(3 * (ru.x - lu.x + rd.x - ld.x));
          center.y = lu.y;    
          circle(src, Point(center.x,center.y), 1, Scalar(0,0,255), 2, 8);  
          /*找到并标出梯形几何中心*/
       } 


     else{
     //cout << temp_contours.size() <<endl;
     //cout << contours.size() <<endl;

     Point2f ld1[lightbars_.size()], ru1[lightbars_.size()], rd1[lightbars_.size()];
     for(int j = 0; j < contours.size(); j++){
         for(int k = 1; k < contours[j].size(); k++){
              if(contours[j][k].x < contours[j][k-1].x){
              //lu.x = contours[j][k].x;//左上的x
              ld.x = contours[j][k].x;//左下的x
               }
              if(contours[j][k].y > contours[j][k-1].y){
                ld.y = contours[j][k].y;      
               }
              if(contours[j][k].x > contours[j][k - 1].x){
                rd.x = contours[j][k].x;
               } 
              if(contours[j][k].y < contours[j][k - 1].y){
                ru.y = contours[j][k].y;
                ru.x = contours[j][k].x;
                //lu.y = contours[j][k].y;
               }
        } 
         ld1[j].x = ld.x;
         ld1[j].y = ld.y;
         rd1[j].x = rd.x;
         ru1[j].y = ru.y;
         ru1[j].x = ru.x;
      }
      for(int i = 1; i < lightbars_.size(); i++){
         if(ld1[i].x < ld1[i - 1].x){
           ld.x = ld1[i].x;
         }
         else{
           rd.x = ld1[i].x;
         }
         if(ld1[i].y > ld1[i - 1].y){
           ld.y = ld1[i].y;
         }
         if(rd1[i].x > rd1[i - 1].x){
           rd.x = rd1[i].x;
         }
         if(ru1[i].y < ru1[i - 1].y){
           ru.y = ru1[i].y;
         }
         if(ru1[i].x > ru1[i - 1].x){
           ru.x = ru1[i].x;
         }
         else{
           lu.x = ru1[i].x;
            }
          
         
      } 
        
        rd.y = ld.y;
        lu.y = ru.y; 


         
          circle(src, Point(lu.x,lu.y), 1, Scalar(0,255,0),2,8);   
          circle(src, Point(ld.x,ld.y), 1, Scalar(0,255,0),2,8);  
          circle(src, Point(ru.x,ru.y), 1, Scalar(0,255,0),2,8);   
          circle(src, Point(rd.x,rd.y), 1, Scalar(0,255,0),2,8);  
          line(src, lu, ru, (0, 255, 255), 2);
          line(src, ru, rd, (0, 255, 255), 2);
          line(src, rd, ld, (0, 255, 255), 2);
          line(src, ld, lu, (0, 255, 255), 2);
    

          Point2f center;
          center.x = (lu.x + ru.x) *0.5;
          center.y = ld.y - (ld.y - lu.y)*(2 * (ru.x - lu.x) + (rd.x - ld.x))/(3 * (ru.x - lu.x + rd.x - ld.x));  
          center.y = lu.y;  
          circle(src, Point(center.x,center.y), 1, Scalar(0,255,0), 1, 8); 
         }
    
        /*target_solver.run(lightbars_, target);*/
        /*namedWindow("src", WINDOW_NORMAL);*/
        imshow("src", src);
        waitKey(0);
     }
    
    return 0;
}
     

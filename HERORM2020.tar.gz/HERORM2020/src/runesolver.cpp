/******************************************************************************
 Copyright© HITwh HERO-RoboMaster2020 Group

 Author: Wang Xiaoyan on 2019.9.20

 Detail:
 *****************************************************************************/

#include "runesolver.h"


RuneSolver::RuneSolver() {

}

RuneSolver::~RuneSolver() {

}

void RuneSolver::init() {

}

void RuneSolver::run(const Mat &src, double &x, double &y, double &z) {
    x = 0.0;
    y = 0.0;
    z = 0.0;
}
